package com.example.trekkers_pk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
